plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.contoh.jadwalku"
    compileSdk = 34

    // Kunci debug tetap: semua build punya tanda tangan yang sama,
    // jadi APK baru bisa dipasang di atas yang lama tanpa menghapus data.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        // Kunci rilis: dibaca dari variabel lingkungan (diisi GitHub Secrets).
        // Kalau tidak ada, bagian ini dilewati dan build rilis tidak dibuat.
        val releaseStore = System.getenv("KEYSTORE_FILE")
        if (releaseStore != null && file(releaseStore).exists()) {
            create("release") {
                storeFile = file(releaseStore)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }

    defaultConfig {
        applicationId = "com.contoh.jadwalku"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "1.4.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.12.0")
}
