package com.contoh.jadwalku

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

/** Menyimpan pilihan tema: ikuti sistem, terang, atau gelap. */
object ThemePrefs {

    fun get(context: Context): Int =
        context.getSharedPreferences("tema", Context.MODE_PRIVATE)
            .getInt("mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)

    fun set(context: Context, mode: Int) {
        context.getSharedPreferences("tema", Context.MODE_PRIVATE)
            .edit().putInt("mode", mode).apply()
    }
}
