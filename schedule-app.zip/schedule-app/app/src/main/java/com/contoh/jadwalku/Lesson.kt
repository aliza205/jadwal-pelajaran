package com.contoh.jadwalku

/**
 * Satu pelajaran di jadwal.
 * day: 0 = Senin, 1 = Selasa, ... 6 = Minggu
 * start/end: jam dalam format "HH:mm", contoh "07:30"
 */
data class Lesson(
    val id: Long,
    val name: String,
    val teacher: String,
    val room: String,
    val day: Int,
    val start: String,
    val end: String,
    val color: Int
)

/** Pilihan warna untuk kartu pelajaran. */
object Palette {
    val colors = listOf(
        0xFF6C5CE7.toInt(), // ungu
        0xFF00B894.toInt(), // hijau
        0xFFFF7675.toInt(), // merah muda
        0xFFFDCB6E.toInt(), // kuning
        0xFF0984E3.toInt(), // biru
        0xFFE17055.toInt()  // oranye
    )
}
