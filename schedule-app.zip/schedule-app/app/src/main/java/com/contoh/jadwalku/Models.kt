package com.contoh.jadwalku

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

/** Satu tugas / PR. due = tenggat dalam format "yyyy-MM-dd". */
data class Homework(
    val id: Long,
    val title: String,
    val subject: String,
    val due: String,
    val done: Boolean
)

/** Satu nilai. score berkisar 0 - 100. */
data class Grade(
    val id: Long,
    val subject: String,
    val type: String,
    val score: Double
)

/** Menulis angka dengan satu desimal, contoh 85,5 */
fun formatScore(value: Double): String =
    String.format(Locale("id", "ID"), "%.1f", value)

/** Bantuan untuk tanggal. */
object DateUtil {
    private val fmt = DateTimeFormatter.ofPattern("d MMM yyyy", Locale("id", "ID"))

    fun today(): String = LocalDate.now().toString()

    fun pretty(date: String): String = LocalDate.parse(date).format(fmt)

    /** Selisih hari dari hari ini. Negatif berarti sudah lewat. */
    fun daysLeft(date: String): Long =
        ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(date))

    fun label(date: String): String {
        val d = daysLeft(date)
        return when {
            d < 0 -> "Terlambat ${-d} hari"
            d == 0L -> "Hari ini"
            d == 1L -> "Besok"
            d <= 7 -> "$d hari lagi"
            else -> pretty(date)
        }
    }
}
