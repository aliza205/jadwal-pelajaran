package com.contoh.jadwalku

import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnAttach
import androidx.core.view.updatePadding

/**
 * Tambahkan tinggi status bar ke padding atas view ini, sehingga warna latarnya
 * tembus sampai ke belakang status bar sementara isinya tetap di bawah status bar.
 */
fun View.padTopWithStatusBar() {
    val base = paddingTop
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
        val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
        v.updatePadding(top = base + top)
        insets // tidak dikonsumsi, supaya view lain tetap menerimanya
    }
    doOnAttach { ViewCompat.requestApplyInsets(it) }
}
