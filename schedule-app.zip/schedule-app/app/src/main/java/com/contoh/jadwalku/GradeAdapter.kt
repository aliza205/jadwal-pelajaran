package com.contoh.jadwalku

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Menampilkan daftar nilai. */
class GradeAdapter(
    private var items: List<Grade>,
    private val onClick: (Grade) -> Unit
) : RecyclerView.Adapter<GradeAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val score: TextView = view.findViewById(R.id.tvScore)
        val subject: TextView = view.findViewById(R.id.tvSubject)
        val type: TextView = view.findViewById(R.id.tvType)
    }

    fun submit(list: List<Grade>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_grade, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val g = items[position]
        holder.subject.text = g.subject
        holder.type.text = g.type
        holder.score.text = formatScore(g.score)

        // Warna lencana: hijau (baik), oranye (cukup), merah (kurang)
        val color = when {
            g.score >= 75 -> "#00B894"
            g.score >= 60 -> "#F39C12"
            else -> "#D63031"
        }
        val badge = GradientDrawable()
        badge.cornerRadius = 14f * holder.itemView.resources.displayMetrics.density
        badge.setColor(Color.parseColor(color))
        holder.score.background = badge

        holder.itemView.setOnClickListener { onClick(g) }
    }

    override fun getItemCount() = items.size
}
