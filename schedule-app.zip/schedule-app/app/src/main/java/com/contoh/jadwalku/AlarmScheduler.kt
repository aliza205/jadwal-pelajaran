package com.contoh.jadwalku

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

/** Mengatur jadwal alarm ke sistem Android (AlarmManager). */
object AlarmScheduler {

    const val EXTRA_ID = "alarm_id"
    const val EXTRA_SNOOZE = "snooze"
    private const val SNOOZE_BASE = 1_000_000_000

    /** Waktu bunyi berikutnya (dalam milidetik) untuk sebuah alarm. */
    fun nextTrigger(item: AlarmItem): Long {
        val now = System.currentTimeMillis()
        for (offset in 0..7) {
            val cal = Calendar.getInstance()
            cal.set(Calendar.HOUR_OF_DAY, item.hour)
            cal.set(Calendar.MINUTE, item.minute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            cal.add(Calendar.DAY_OF_YEAR, offset)

            val dayIndex = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Senin = 0
            val dayOk = item.days.isEmpty() || item.days.contains(dayIndex)
            if (dayOk && cal.timeInMillis > now) return cal.timeInMillis
        }
        return now + 24 * 60 * 60 * 1000L
    }

    /** Teks seperti "8 jam 44 menit" sampai waktu bunyi. */
    fun untilText(trigger: Long): String {
        val minutes = ((trigger - System.currentTimeMillis()) / 60_000L).coerceAtLeast(0L)
        val h = minutes / 60
        val m = minutes % 60
        return when {
            h > 0 && m > 0 -> "$h jam $m menit"
            h > 0 -> "$h jam"
            m > 0 -> "$m menit"
            else -> "kurang dari 1 menit"
        }
    }

    private fun firePendingIntent(ctx: Context, requestCode: Int, id: Long, snooze: Boolean): PendingIntent {
        val intent = Intent(ctx, AlarmReceiver::class.java)
            .putExtra(EXTRA_ID, id)
            .putExtra(EXTRA_SNOOZE, snooze)
        return PendingIntent.getBroadcast(
            ctx, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Intent yang dibuka kalau ikon alarm di status bar diketuk. */
    private fun showPendingIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

    fun schedule(ctx: Context, item: AlarmItem) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val info = AlarmManager.AlarmClockInfo(nextTrigger(item), showPendingIntent(ctx))
        am.setAlarmClock(info, firePendingIntent(ctx, item.requestCode, item.id, false))
    }

    fun cancel(ctx: Context, item: AlarmItem) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(firePendingIntent(ctx, item.requestCode, item.id, false))
    }

    /** Tunda: bunyi lagi beberapa menit dari sekarang. */
    fun snooze(ctx: Context, item: AlarmItem, minutes: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val at = System.currentTimeMillis() + minutes * 60_000L
        val info = AlarmManager.AlarmClockInfo(at, showPendingIntent(ctx))
        am.setAlarmClock(info, firePendingIntent(ctx, SNOOZE_BASE + item.requestCode, item.id, true))
    }

    /** Pasang ulang semua alarm aktif (dipakai setelah HP restart). */
    fun scheduleAll(ctx: Context) {
        AlarmStore(ctx).load().filter { it.enabled }.forEach { schedule(ctx, it) }
    }
}
