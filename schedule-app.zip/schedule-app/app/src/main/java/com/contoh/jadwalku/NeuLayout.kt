package com.contoh.jadwalku

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import kotlin.math.min

/**
 * Wadah bergaya neumorphism: permukaan sewarna latar dengan dua bayangan lembut
 * (terang di kiri atas, gelap di kanan bawah) sehingga tampak menonjol atau cekung.
 *
 * Bayangan digambar DI DALAM batas view, jadi view otomatis diberi padding = 3 x neuDepth.
 * Ukuran bentuk yang terlihat = ukuran view dikurangi padding itu.
 */
class NeuLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    companion object {
        const val FLAT = 0
        const val RAISED = 1
        const val INSET = 2
    }

    /** FLAT / RAISED / INSET. RAISED otomatis tampil cekung saat ditekan. */
    var mode: Int = RAISED
        set(value) {
            field = value
            invalidate()
        }

    private var depth = 0f
    private var radius = 0f
    private var circle = false
    private var notchRadius = 0f

    private val surface = ContextCompat.getColor(context, R.color.neu_surface)
    private val lightColor = ContextCompat.getColor(context, R.color.neu_light)
    private val darkColor = ContextCompat.getColor(context, R.color.neu_dark)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shape = Path()
    private val frame = Path() // dipakai untuk bayangan dalam (mode cekung)

    init {
        val a = context.obtainStyledAttributes(attrs, R.styleable.NeuLayout)
        mode = a.getInt(R.styleable.NeuLayout_neuMode, RAISED)
        depth = a.getDimension(R.styleable.NeuLayout_neuDepth, 4f * resources.displayMetrics.density)
        radius = a.getDimension(R.styleable.NeuLayout_neuRadius, 0f)
        circle = a.getBoolean(R.styleable.NeuLayout_neuCircle, false)
        notchRadius = a.getDimension(R.styleable.NeuLayout_neuNotchRadius, 0f)
        a.recycle()

        setWillNotDraw(false)
        // Bayangan blur butuh software layer di Android lama
        setLayerType(LAYER_TYPE_SOFTWARE, null)

        val pad = (depth * 3).toInt()
        setPadding(pad, pad, pad, pad)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        buildShape(w.toFloat(), h.toFloat())
    }

    private fun buildShape(w: Float, h: Float) {
        val pad = depth * 3
        val l = pad
        val t = pad
        val r = w - pad
        val b = h - pad
        if (r <= l || b <= t) return

        shape.reset()
        if (circle) {
            shape.addCircle((l + r) / 2f, (t + b) / 2f, min(r - l, b - t) / 2f, Path.Direction.CW)
        } else {
            val cr = min(radius, min(r - l, b - t) / 2f)
            if (notchRadius > 0f) {
                // Persegi membulat dengan lekukan setengah lingkaran di tengah sisi atas
                val cx = (l + r) / 2f
                val nr = notchRadius
                shape.moveTo(l + cr, t)
                shape.lineTo(cx - nr, t)
                shape.arcTo(RectF(cx - nr, t - nr, cx + nr, t + nr), 180f, -180f)
                shape.lineTo(r - cr, t)
                shape.arcTo(RectF(r - 2 * cr, t, r, t + 2 * cr), 270f, 90f)
                shape.lineTo(r, b - cr)
                shape.arcTo(RectF(r - 2 * cr, b - 2 * cr, r, b), 0f, 90f)
                shape.lineTo(l + cr, b)
                shape.arcTo(RectF(l, b - 2 * cr, l + 2 * cr, b), 90f, 90f)
                shape.lineTo(l, t + cr)
                shape.arcTo(RectF(l, t, l + 2 * cr, t + 2 * cr), 180f, 90f)
                shape.close()
            } else {
                shape.addRoundRect(RectF(l, t, r, b), cr, cr, Path.Direction.CW)
            }
        }

        // Bingkai besar dengan lubang berbentuk shape: bayangannya jatuh ke dalam lubang
        frame.reset()
        frame.addRect(-4000f, -4000f, w + 4000f, h + 4000f, Path.Direction.CW)
        frame.addPath(shape)
        frame.fillType = Path.FillType.EVEN_ODD
    }

    override fun drawableStateChanged() {
        super.drawableStateChanged()
        invalidate() // gambar ulang saat ditekan / dilepas
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (shape.isEmpty) return

        val effective = if (mode == RAISED && isPressed) INSET else mode
        val offset = depth
        val blur = depth * 2f
        paint.style = Paint.Style.FILL
        paint.color = surface

        when (effective) {
            RAISED -> {
                paint.setShadowLayer(blur, offset, offset, darkColor)
                canvas.drawPath(shape, paint)
                paint.setShadowLayer(blur, -offset, -offset, lightColor)
                canvas.drawPath(shape, paint)
                paint.clearShadowLayer()
                canvas.drawPath(shape, paint)
            }
            INSET -> {
                canvas.save()
                canvas.clipPath(shape)
                paint.clearShadowLayer()
                canvas.drawPath(shape, paint)
                paint.setShadowLayer(blur, offset, offset, darkColor)
                canvas.drawPath(frame, paint)
                paint.setShadowLayer(blur, -offset, -offset, lightColor)
                canvas.drawPath(frame, paint)
                paint.clearShadowLayer()
                canvas.restore()
            }
            else -> Unit // FLAT: tanpa bayangan
        }
    }
}
