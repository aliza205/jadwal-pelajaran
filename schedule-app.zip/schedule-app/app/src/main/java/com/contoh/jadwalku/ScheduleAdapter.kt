package com.contoh.jadwalku

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Menampilkan daftar pelajaran sebagai kartu. */
class ScheduleAdapter(
    private var items: List<Lesson>,
    private val onClick: (Lesson) -> Unit
) : RecyclerView.Adapter<ScheduleAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val bar: View = view.findViewById(R.id.colorBar)
        val start: TextView = view.findViewById(R.id.tvStart)
        val end: TextView = view.findViewById(R.id.tvEnd)
        val name: TextView = view.findViewById(R.id.tvName)
        val detail: TextView = view.findViewById(R.id.tvDetail)
    }

    fun submit(list: List<Lesson>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_schedule, parent, false)
        // Latar timbul neumorphism (bayangan 6dp + 3dp = 9dp, sama dengan padding di item_schedule.xml)
        view.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        view.background = NeumorphDrawable(parent.context, cornerDp = 20f, blurDp = 6f, offsetDp = 3f)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val l = items[position]
        holder.bar.background = GradientDrawable().apply {
            setColor(l.color)
            cornerRadius = 8f * holder.itemView.resources.displayMetrics.density
        }
        holder.start.text = l.start
        holder.end.text = l.end
        holder.name.text = l.name

        // Gabungkan guru dan ruang, lewati yang kosong
        holder.detail.text = listOf(l.teacher, l.room)
            .filter { it.isNotBlank() }
            .joinToString("  •  ")

        holder.itemView.setOnClickListener { onClick(l) }
    }

    override fun getItemCount() = items.size
}
