package com.contoh.jadwalku

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Menyimpan daftar alarm di HP. */
class AlarmStore(context: Context) {

    private val prefs = context.getSharedPreferences("alarm", Context.MODE_PRIVATE)

    fun load(): MutableList<AlarmItem> {
        val text = prefs.getString("items", null) ?: return mutableListOf()
        val array = JSONArray(text)
        val list = mutableListOf<AlarmItem>()
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            val d = o.getJSONArray("days")
            list.add(
                AlarmItem(
                    id = o.getLong("id"),
                    hour = o.getInt("hour"),
                    minute = o.getInt("minute"),
                    label = o.getString("label"),
                    days = (0 until d.length()).map { d.getInt(it) },
                    enabled = o.getBoolean("enabled")
                )
            )
        }
        return list
    }

    fun save(list: List<AlarmItem>) {
        val array = JSONArray()
        for (a in list) {
            val days = JSONArray()
            a.days.forEach { days.put(it) }
            array.put(
                JSONObject()
                    .put("id", a.id)
                    .put("hour", a.hour)
                    .put("minute", a.minute)
                    .put("label", a.label)
                    .put("days", days)
                    .put("enabled", a.enabled)
            )
        }
        prefs.edit().putString("items", array.toString()).apply()
    }
}
