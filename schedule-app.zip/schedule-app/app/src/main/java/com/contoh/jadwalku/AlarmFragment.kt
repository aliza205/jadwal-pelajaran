package com.contoh.jadwalku

import android.Manifest
import android.app.TimePickerDialog
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText

/** Halaman Alarm: alarm bangun pagi yang bisa diatur, diulang, dan dimatikan. */
class AlarmFragment : Fragment(R.layout.fragment_alarm), Addable {

    private lateinit var store: AlarmStore
    private lateinit var items: MutableList<AlarmItem>
    private lateinit var adapter: AlarmAdapter
    private lateinit var tvSubtitle: TextView
    private lateinit var tvEmpty: TextView

    // Izin notifikasi (Android 13+). Setelah dijawab, lanjut buka form tambah alarm.
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { showEditor(null) }

    private val chipIds = listOf(
        R.id.chipMon, R.id.chipTue, R.id.chipWed, R.id.chipThu,
        R.id.chipFri, R.id.chipSat, R.id.chipSun
    )

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<View>(R.id.header)?.padTopWithStatusBar()

        store = AlarmStore(requireContext())
        items = store.load()

        view.findViewById<TextView>(R.id.tvTitle).text = "Alarm Bangun Pagi"
        tvSubtitle = view.findViewById(R.id.tvSubtitle)
        tvEmpty = view.findViewById(R.id.tvEmpty)

        val recycler = view.findViewById<RecyclerView>(R.id.recyclerView)
        recycler.layoutManager = LinearLayoutManager(requireContext())
        adapter = AlarmAdapter(
            emptyList(),
            onClick = { showEditor(it) },
            onToggle = { alarm, checked -> toggle(alarm, checked) }
        )
        recycler.adapter = adapter

        refresh()
    }

    // Segarkan saat halaman ditampilkan lagi (alarm sekali bisa sudah mati sendiri)
    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden && view != null) refresh()
    }

    override fun onResume() {
        super.onResume()
        if (!isHidden && view != null) refresh()
    }

    /** Dipanggil saat tombol + di bar bawah diketuk. */
    override fun onAdd() {
        val needPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                requireContext(), Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        if (needPermission) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            showEditor(null)
        }
    }

    private fun refresh() {
        items = store.load()
        val sorted = items.sortedBy { it.hour * 60 + it.minute }
        adapter.submit(sorted)
        tvEmpty.visibility = if (sorted.isEmpty()) View.VISIBLE else View.GONE

        val active = items.filter { it.enabled }
        tvSubtitle.text = if (active.isEmpty()) {
            "Tidak ada alarm aktif"
        } else {
            val next = active.minOf { AlarmScheduler.nextTrigger(it) }
            "Alarm berbunyi ${AlarmScheduler.untilText(next)} lagi"
        }
    }

    private fun toggle(alarm: AlarmItem, checked: Boolean) {
        val index = items.indexOfFirst { it.id == alarm.id }
        if (index < 0) return
        val updated = alarm.copy(enabled = checked)
        items[index] = updated
        store.save(items)

        val ctx = requireContext()
        if (checked) {
            AlarmScheduler.schedule(ctx, updated)
            toastUntil(updated)
        } else {
            AlarmScheduler.cancel(ctx, updated)
        }
        refresh()
    }

    private fun toastUntil(alarm: AlarmItem) {
        val text = "Alarm berbunyi ${AlarmScheduler.untilText(AlarmScheduler.nextTrigger(alarm))} lagi"
        Toast.makeText(requireContext(), text, Toast.LENGTH_SHORT).show()
    }

    private fun showEditor(existing: AlarmItem?) {
        val ctx = requireContext()
        val view = layoutInflater.inflate(R.layout.dialog_alarm, null)
        val btnTime = view.findViewById<Button>(R.id.btnTime)
        val etLabel = view.findViewById<TextInputEditText>(R.id.etLabel)

        // Alarm baru: 05:30, Senin sampai Sabtu
        var hour = existing?.hour ?: 5
        var minute = existing?.minute ?: 30
        btnTime.text = String.format("%02d:%02d", hour, minute)
        btnTime.setOnClickListener {
            TimePickerDialog(
                ctx,
                { _, h, m ->
                    hour = h
                    minute = m
                    btnTime.text = String.format("%02d:%02d", h, m)
                },
                hour, minute, true
            ).show()
        }

        etLabel.setText(existing?.label ?: "Bangun pagi")

        val selectedDays = existing?.days ?: listOf(0, 1, 2, 3, 4, 5)
        chipIds.forEachIndexed { index, id ->
            view.findViewById<Chip>(id).isChecked = selectedDays.contains(index)
        }

        val builder = MaterialAlertDialogBuilder(ctx)
            .setTitle(if (existing == null) "Tambah alarm" else "Edit alarm")
            .setView(view)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)

        if (existing != null) {
            builder.setNeutralButton("Hapus") { _, _ ->
                AlarmScheduler.cancel(ctx, existing)
                items.removeAll { it.id == existing.id }
                store.save(items)
                refresh()
            }
        }

        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val days = chipIds.mapIndexedNotNull { index, id ->
                    if (view.findViewById<Chip>(id).isChecked) index else null
                }
                val alarm = AlarmItem(
                    id = existing?.id ?: System.currentTimeMillis(),
                    hour = hour,
                    minute = minute,
                    label = etLabel.text.toString().trim(),
                    days = days,
                    enabled = true // menyimpan berarti mengaktifkan
                )

                if (existing == null) {
                    items.add(alarm)
                } else {
                    val index = items.indexOfFirst { it.id == existing.id }
                    if (index >= 0) items[index] = alarm
                }
                store.save(items)
                AlarmScheduler.schedule(ctx, alarm)
                toastUntil(alarm)
                refresh()
                dialog.dismiss()
            }
        }
        dialog.show()
    }
}
