package com.contoh.jadwalku

/**
 * Satu alarm.
 * days: hari berulang, 0 = Senin ... 6 = Minggu. Kosong berarti berbunyi sekali saja.
 */
data class AlarmItem(
    val id: Long,
    val hour: Int,
    val minute: Int,
    val label: String,
    val days: List<Int>,
    val enabled: Boolean
) {
    val timeText: String get() = String.format("%02d:%02d", hour, minute)

    /** Nomor unik untuk PendingIntent (harus kurang dari 1 miliar). */
    val requestCode: Int get() = (id % 1_000_000_000L).toInt()
}

object DayNames {
    val short = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
}

/** Teks ringkas untuk hari berulang. */
fun daysLabel(days: List<Int>): String {
    val sorted = days.sorted()
    return when {
        sorted.isEmpty() -> "Sekali saja"
        sorted.size == 7 -> "Setiap hari"
        sorted == listOf(0, 1, 2, 3, 4) -> "Senin - Jumat"
        sorted == listOf(0, 1, 2, 3, 4, 5) -> "Senin - Sabtu"
        else -> sorted.joinToString(" ") { DayNames.short[it] }
    }
}
