package com.contoh.jadwalku

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import androidx.core.content.ContextCompat

/**
 * Latar bergaya neumorphism: permukaan satu warna dengan dua bayangan lembut,
 * terang di kiri atas dan gelap di kanan bawah.
 *
 * - inset = false: permukaan timbul (menonjol). Bentuk digambar dengan jarak aman
 *   di dalam batas view supaya bayangan tidak terpotong.
 * - inset = true : permukaan cekung (tertekan), dipakai untuk menu yang aktif.
 *
 * Pasang pada view dengan view.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
 * supaya bayangan tampil di semua versi Android.
 */
class NeumorphDrawable(
    context: Context,
    cornerDp: Float,
    private val inset: Boolean = false,
    private val fillColor: Int = ContextCompat.getColor(context, R.color.bg),
    blurDp: Float = 10f,
    offsetDp: Float = 5f
) : Drawable() {

    private val density = context.resources.displayMetrics.density
    private val blur = blurDp * density
    private val offset = offsetDp * density
    private val corner = cornerDp * density
    private val light = ContextCompat.getColor(context, R.color.nm_light)
    private val dark = ContextCompat.getColor(context, R.color.nm_dark)

    private val body = RectF()
    private val bodyPath = Path()
    private val ringPath = Path()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onBoundsChange(bounds: Rect) {
        // Permukaan timbul disisakan ruang untuk bayangannya
        val pad = if (inset) 0f else blur + offset
        body.set(bounds.left + pad, bounds.top + pad, bounds.right - pad, bounds.bottom - pad)
    }

    override fun draw(canvas: Canvas) {
        if (body.isEmpty) return
        val r = minOf(corner, body.width() / 2f, body.height() / 2f)
        paint.style = Paint.Style.FILL
        paint.color = fillColor

        if (!inset) {
            // Bayangan gelap (kanan bawah), lalu bayangan terang (kiri atas)
            paint.setShadowLayer(blur, offset, offset, dark)
            canvas.drawRoundRect(body, r, r, paint)
            paint.setShadowLayer(blur, -offset, -offset, light)
            canvas.drawRoundRect(body, r, r, paint)
            // Gambar permukaan sekali lagi tanpa bayangan supaya bersih
            paint.clearShadowLayer()
            canvas.drawRoundRect(body, r, r, paint)
        } else {
            paint.clearShadowLayer()
            canvas.drawRoundRect(body, r, r, paint)

            // Bayangan jatuh ke dalam: gelap di kiri atas, terang di kanan bawah
            bodyPath.reset()
            bodyPath.addRoundRect(body, r, r, Path.Direction.CW)

            val big = blur * 3 + offset * 2
            ringPath.reset()
            ringPath.fillType = Path.FillType.EVEN_ODD
            ringPath.addRect(
                body.left - big, body.top - big, body.right + big, body.bottom + big,
                Path.Direction.CW
            )
            ringPath.addRoundRect(body, r, r, Path.Direction.CW)

            canvas.save()
            canvas.clipPath(bodyPath)
            paint.setShadowLayer(blur, offset, offset, dark)
            canvas.drawPath(ringPath, paint)
            paint.setShadowLayer(blur, -offset, -offset, light)
            canvas.drawPath(ringPath, paint)
            canvas.restore()
        }
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
