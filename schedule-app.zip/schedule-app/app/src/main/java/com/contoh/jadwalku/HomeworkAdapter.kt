package com.contoh.jadwalku

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.core.content.ContextCompat

/** Menampilkan daftar tugas / PR. */
class HomeworkAdapter(
    private var items: List<Homework>,
    private val onClick: (Homework) -> Unit,
    private val onCheck: (Homework, Boolean) -> Unit
) : RecyclerView.Adapter<HomeworkAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val check: CheckBox = view.findViewById(R.id.cbDone)
        val title: TextView = view.findViewById(R.id.tvTitle)
        val sub: TextView = view.findViewById(R.id.tvSub)
    }

    fun submit(list: List<Homework>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_task, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val h = items[position]

        // Lepas listener lama dulu supaya tidak terpanggil saat mengisi ulang
        holder.check.setOnCheckedChangeListener(null)
        holder.check.isChecked = h.done

        holder.title.text = h.title
        if (h.done) {
            holder.title.paintFlags = holder.title.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            holder.title.alpha = 0.5f
        } else {
            holder.title.paintFlags = holder.title.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            holder.title.alpha = 1f
        }

        holder.sub.text = listOf(h.subject, DateUtil.label(h.due))
            .filter { it.isNotBlank() }
            .joinToString("  •  ")

        // Tugas yang terlambat ditandai merah
        val late = !h.done && DateUtil.daysLeft(h.due) < 0
        holder.sub.setTextColor(
            ContextCompat.getColor(
                holder.itemView.context,
                if (late) R.color.danger else R.color.text_secondary
            )
        )

        holder.check.setOnCheckedChangeListener { _, checked -> onCheck(h, checked) }
        holder.itemView.setOnClickListener { onClick(h) }
    }

    override fun getItemCount() = items.size
}
