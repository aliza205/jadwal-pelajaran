package com.contoh.jadwalku

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Setelah HP restart atau aplikasi diperbarui, alarm harus dipasang ulang. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmScheduler.scheduleAll(context)
    }
}
