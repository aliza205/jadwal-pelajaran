package com.contoh.jadwalku

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Menyimpan daftar nilai. */
class GradeStore(context: Context) {

    private val prefs = context.getSharedPreferences("nilai", Context.MODE_PRIVATE)

    fun load(): MutableList<Grade> {
        val text = prefs.getString("items", null) ?: return mutableListOf()
        val array = JSONArray(text)
        val list = mutableListOf<Grade>()
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            list.add(
                Grade(
                    id = o.getLong("id"),
                    subject = o.getString("subject"),
                    type = o.getString("type"),
                    score = o.getDouble("score")
                )
            )
        }
        return list
    }

    fun save(list: List<Grade>) {
        val array = JSONArray()
        for (g in list) {
            array.put(
                JSONObject()
                    .put("id", g.id)
                    .put("subject", g.subject)
                    .put("type", g.type)
                    .put("score", g.score)
            )
        }
        prefs.edit().putString("items", array.toString()).apply()
    }
}
