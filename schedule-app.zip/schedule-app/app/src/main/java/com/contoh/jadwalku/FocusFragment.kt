package com.contoh.jadwalku

import android.content.Context
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButtonToggleGroup

/** Halaman Fokus: timer belajar (teknik Pomodoro). */
class FocusFragment : Fragment(R.layout.fragment_focus) {

    private lateinit var tvTime: TextView
    private lateinit var tvDone: TextView
    private lateinit var btnStartPause: Button

    private var timer: CountDownTimer? = null
    private var running = false
    private var isFocusMode = true
    private var totalMs = 25 * 60_000L
    private var remainingMs = totalMs

    private val prefs by lazy {
        requireContext().getSharedPreferences("fokus", Context.MODE_PRIVATE)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<TextView>(R.id.tvTitle).text = "Fokus Belajar"
        view.findViewById<TextView>(R.id.tvSubtitle).text = "Belajar tanpa gangguan"

        tvTime = view.findViewById(R.id.tvTime)
        tvDone = view.findViewById(R.id.tvDone)
        btnStartPause = view.findViewById(R.id.btnStartPause)

        val group = view.findViewById<MaterialButtonToggleGroup>(R.id.toggleMode)
        group.check(R.id.btnFocus)
        group.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            when (checkedId) {
                R.id.btnFocus -> setMode(25, true)
                R.id.btnShort -> setMode(5, false)
                R.id.btnLong -> setMode(15, false)
            }
        }

        btnStartPause.setOnClickListener { if (running) pause() else start() }
        view.findViewById<Button>(R.id.btnReset).setOnClickListener { resetTimer() }

        updateTime()
        updateDoneCount()
    }

    private fun setMode(minutes: Int, focus: Boolean) {
        isFocusMode = focus
        totalMs = minutes * 60_000L
        resetTimer()
    }

    private fun start() {
        running = true
        btnStartPause.text = "Jeda"
        view?.keepScreenOn = true
        timer = object : CountDownTimer(remainingMs, 1000) {
            override fun onTick(ms: Long) {
                remainingMs = ms
                updateTime()
            }

            override fun onFinish() {
                finishSession()
            }
        }.start()
    }

    private fun pause() {
        timer?.cancel()
        running = false
        btnStartPause.text = "Lanjut"
        view?.keepScreenOn = false
    }

    private fun resetTimer() {
        timer?.cancel()
        running = false
        remainingMs = totalMs
        btnStartPause.text = "Mulai"
        view?.keepScreenOn = false
        updateTime()
    }

    private fun finishSession() {
        if (isFocusMode) {
            val key = "count_${DateUtil.today()}"
            prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
            updateDoneCount()
            Toast.makeText(requireContext(), "Sesi fokus selesai! Waktunya istirahat.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(requireContext(), "Istirahat selesai. Ayo belajar lagi!", Toast.LENGTH_LONG).show()
        }
        resetTimer()
    }

    private fun updateTime() {
        val seconds = (remainingMs + 999) / 1000
        tvTime.text = String.format("%02d:%02d", seconds / 60, seconds % 60)
    }

    private fun updateDoneCount() {
        val count = prefs.getInt("count_${DateUtil.today()}", 0)
        tvDone.text = "Sesi fokus selesai hari ini: $count"
    }

    override fun onDestroyView() {
        timer?.cancel()
        super.onDestroyView()
    }
}
