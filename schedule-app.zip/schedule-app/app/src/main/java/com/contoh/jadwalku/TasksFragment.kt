package com.contoh.jadwalku

import android.app.DatePickerDialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import java.time.LocalDate

/** Halaman Tugas & PR: daftar tugas dengan tenggat dan centang selesai. */
class TasksFragment : Fragment(R.layout.fragment_tasks) {

    private lateinit var store: HomeworkStore
    private lateinit var items: MutableList<Homework>
    private lateinit var adapter: HomeworkAdapter
    private lateinit var tvSubtitle: TextView
    private lateinit var tvEmpty: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        store = HomeworkStore(requireContext())
        items = store.load()

        view.findViewById<TextView>(R.id.tvTitle).text = "Tugas & PR"
        tvSubtitle = view.findViewById(R.id.tvSubtitle)
        tvEmpty = view.findViewById(R.id.tvEmpty)

        val recycler = view.findViewById<RecyclerView>(R.id.recyclerView)
        recycler.layoutManager = LinearLayoutManager(requireContext())
        adapter = HomeworkAdapter(
            emptyList(),
            onClick = { showEditor(it) },
            onCheck = { task, checked ->
                val index = items.indexOfFirst { it.id == task.id }
                if (index >= 0) {
                    items[index] = task.copy(done = checked)
                    store.save(items)
                    refresh()
                }
            }
        )
        recycler.adapter = adapter

        view.findViewById<FloatingActionButton>(R.id.fabAdd).setOnClickListener { showEditor(null) }

        refresh()
    }

    /** Yang belum selesai di atas (urut tenggat), yang sudah selesai di bawah. */
    private fun refresh() {
        val sorted = items.sortedWith(compareBy<Homework>({ it.done }, { it.due }))
        adapter.submit(sorted)
        tvEmpty.visibility = if (sorted.isEmpty()) View.VISIBLE else View.GONE

        val pending = items.count { !it.done }
        tvSubtitle.text = if (pending == 0) "Semua tugas beres 🎉" else "$pending tugas belum selesai"
    }

    private fun showEditor(existing: Homework?) {
        val ctx = requireContext()
        val view = layoutInflater.inflate(R.layout.dialog_task, null)
        val etTitle = view.findViewById<TextInputEditText>(R.id.etTitle)
        val acSubject = view.findViewById<MaterialAutoCompleteTextView>(R.id.acSubject)
        val btnDate = view.findViewById<Button>(R.id.btnDate)

        // Saran mata pelajaran diambil dari jadwal
        val subjects = ScheduleStore(ctx).load().map { it.name }.distinct().sorted()
        acSubject.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_dropdown_item_1line, subjects))

        etTitle.setText(existing?.title ?: "")
        acSubject.setText(existing?.subject ?: "")

        var due = existing?.due ?: LocalDate.now().plusDays(1).toString()
        btnDate.text = "Tenggat  ${DateUtil.pretty(due)}"
        btnDate.setOnClickListener {
            val d = LocalDate.parse(due)
            DatePickerDialog(
                ctx,
                { _, y, m, day ->
                    due = LocalDate.of(y, m + 1, day).toString()
                    btnDate.text = "Tenggat  ${DateUtil.pretty(due)}"
                },
                d.year, d.monthValue - 1, d.dayOfMonth
            ).show()
        }

        val builder = MaterialAlertDialogBuilder(ctx)
            .setTitle(if (existing == null) "Tambah tugas" else "Edit tugas")
            .setView(view)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)

        if (existing != null) {
            builder.setNeutralButton("Hapus") { _, _ ->
                items.removeAll { it.id == existing.id }
                store.save(items)
                refresh()
            }
        }

        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val title = etTitle.text.toString().trim()
                if (title.isEmpty()) {
                    etTitle.error = "Judul tugas wajib diisi"
                    return@setOnClickListener
                }
                val task = Homework(
                    id = existing?.id ?: System.currentTimeMillis(),
                    title = title,
                    subject = acSubject.text.toString().trim(),
                    due = due,
                    done = existing?.done ?: false
                )
                if (existing == null) {
                    items.add(task)
                } else {
                    val index = items.indexOfFirst { it.id == existing.id }
                    if (index >= 0) items[index] = task
                }
                store.save(items)
                refresh()
                dialog.dismiss()
            }
        }
        dialog.show()
    }
}
