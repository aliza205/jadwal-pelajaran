package com.contoh.jadwalku

/** Halaman yang punya aksi "tambah" lewat tombol + di tengah bar bawah. */
interface Addable {
    fun onAdd()
}
