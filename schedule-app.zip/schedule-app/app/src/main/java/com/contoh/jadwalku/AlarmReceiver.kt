package com.contoh.jadwalku

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Dipanggil sistem tepat saat waktu alarm tiba. */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(AlarmScheduler.EXTRA_ID, -1L)
        val isSnooze = intent.getBooleanExtra(AlarmScheduler.EXTRA_SNOOZE, false)

        if (!isSnooze) {
            val store = AlarmStore(context)
            val list = store.load()
            val index = list.indexOfFirst { it.id == id }
            if (index >= 0) {
                val item = list[index]
                if (item.days.isEmpty()) {
                    // Alarm sekali saja: matikan setelah berbunyi
                    list[index] = item.copy(enabled = false)
                    store.save(list)
                } else {
                    // Alarm berulang: jadwalkan untuk hari berikutnya
                    AlarmScheduler.schedule(context, item)
                }
            }
        }

        // Mulai layanan yang membunyikan alarm
        val service = Intent(context, AlarmService::class.java)
            .putExtra(AlarmScheduler.EXTRA_ID, id)
        try {
            ContextCompat.startForegroundService(context, service)
        } catch (e: Exception) {
            // Sistem (mis. penghemat baterai) menolak layanan alarm: catat, jangan crash
            CrashStore.save(context, "AlarmReceiver: gagal membunyikan alarm", e)
        }
    }
}
