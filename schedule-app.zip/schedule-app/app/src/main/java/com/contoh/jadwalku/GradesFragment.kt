package com.contoh.jadwalku

import android.content.DialogInterface
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText

/** Halaman Nilai: catat nilai dan lihat rata-rata per pelajaran. */
class GradesFragment : Fragment(R.layout.fragment_grades), Addable {

    private val types = listOf("Ulangan Harian", "Tugas", "UTS", "UAS", "Praktik")

    private lateinit var store: GradeStore
    private lateinit var items: MutableList<Grade>
    private lateinit var adapter: GradeAdapter
    private lateinit var tvSubtitle: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var summaryCard: View
    private lateinit var tvAverage: TextView
    private lateinit var tvPerSubject: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<View>(R.id.header)?.padTopWithStatusBar()

        store = GradeStore(requireContext())
        items = store.load()

        view.findViewById<TextView>(R.id.tvTitle).text = "Nilai"
        tvSubtitle = view.findViewById(R.id.tvSubtitle)
        tvEmpty = view.findViewById(R.id.tvEmpty)
        summaryCard = view.findViewById(R.id.summaryCard)
        tvAverage = view.findViewById(R.id.tvAverage)
        tvPerSubject = view.findViewById(R.id.tvPerSubject)

        val recycler = view.findViewById<RecyclerView>(R.id.recyclerView)
        recycler.layoutManager = LinearLayoutManager(requireContext())
        adapter = GradeAdapter(emptyList()) { showEditor(it) }
        recycler.adapter = adapter

        refresh()
    }

    private fun refresh() {
        val sorted = items.sortedWith(compareBy<Grade>({ it.subject.lowercase() }, { -it.id }))
        adapter.submit(sorted)

        val empty = items.isEmpty()
        tvEmpty.visibility = if (empty) View.VISIBLE else View.GONE
        summaryCard.visibility = if (empty) View.GONE else View.VISIBLE
        tvSubtitle.text = "${items.size} nilai tercatat"

        if (!empty) {
            tvAverage.text = formatScore(items.map { it.score }.average())
            tvPerSubject.text = items
                .groupBy { it.subject }
                .toSortedMap()
                .map { (subject, list) -> "$subject: ${formatScore(list.map { it.score }.average())}" }
                .joinToString("\n")
        }
    }

    /** Dipanggil saat tombol + di bar bawah diketuk. */
    override fun onAdd() {
        showEditor(null)
    }

    private fun showEditor(existing: Grade?) {
        val ctx = requireContext()
        val view = layoutInflater.inflate(R.layout.dialog_grade, null)
        val acSubject = view.findViewById<MaterialAutoCompleteTextView>(R.id.acSubject)
        val spType = view.findViewById<Spinner>(R.id.spType)
        val etScore = view.findViewById<TextInputEditText>(R.id.etScore)

        // Saran mata pelajaran dari jadwal dan dari nilai yang sudah ada
        val subjects = (ScheduleStore(ctx).load().map { it.name } + items.map { it.subject })
            .distinct().sorted()
        acSubject.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_dropdown_item_1line, subjects))
        acSubject.setText(existing?.subject ?: "")

        spType.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, types)
        spType.setSelection(types.indexOf(existing?.type).coerceAtLeast(0))

        if (existing != null) etScore.setText(existing.score.toString())

        val builder = MaterialAlertDialogBuilder(ctx)
            .setTitle(if (existing == null) "Tambah nilai" else "Edit nilai")
            .setView(view)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)

        if (existing != null) {
            builder.setNeutralButton("Hapus") { _, _ ->
                items.removeAll { it.id == existing.id }
                store.save(items)
                refresh()
            }
        }

        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val subject = acSubject.text.toString().trim()
                if (subject.isEmpty()) {
                    acSubject.error = "Mata pelajaran wajib diisi"
                    return@setOnClickListener
                }
                // Terima koma maupun titik sebagai pemisah desimal
                val score = etScore.text.toString().trim().replace(',', '.').toDoubleOrNull()
                if (score == null || score < 0 || score > 100) {
                    etScore.error = "Isi nilai 0 - 100"
                    return@setOnClickListener
                }

                val grade = Grade(
                    id = existing?.id ?: System.currentTimeMillis(),
                    subject = subject,
                    type = types[spType.selectedItemPosition],
                    score = score
                )
                if (existing == null) {
                    items.add(grade)
                } else {
                    val index = items.indexOfFirst { it.id == existing.id }
                    if (index >= 0) items[index] = grade
                }
                store.save(items)
                refresh()
                dialog.dismiss()
            }
        }
        dialog.show()
    }
}
