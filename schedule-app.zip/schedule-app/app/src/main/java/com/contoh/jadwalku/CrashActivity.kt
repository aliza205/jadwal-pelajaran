package com.contoh.jadwalku

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Muncul saat aplikasi dibuka lagi setelah error. Menampilkan laporan error
 * yang bisa disalin. Dibuat tanpa file layout supaya tetap jalan walau layout utama bermasalah.
 */
class CrashActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val report = CrashStore.get(this) ?: "(laporan kosong)"
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 2, pad, pad)

        val title = TextView(this)
        title.text = "JadwalKu sempat berhenti"
        title.textSize = 20f
        title.setTypeface(title.typeface, Typeface.BOLD)
        root.addView(title)

        val hint = TextView(this)
        hint.text = "Ketuk Salin laporan, lalu kirim ke pembuat aplikasi supaya masalahnya bisa diperbaiki."
        hint.setPadding(0, pad / 2, 0, pad / 2)
        root.addView(hint)

        val body = TextView(this)
        body.text = report
        body.textSize = 11f
        body.typeface = Typeface.MONOSPACE
        body.setTextIsSelectable(true)
        val scroll = ScrollView(this)
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val btnCopy = Button(this)
        btnCopy.text = "Salin laporan"
        btnCopy.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("laporan error", report))
            Toast.makeText(this, "Laporan disalin", Toast.LENGTH_SHORT).show()
        }
        root.addView(btnCopy)

        val btnContinue = Button(this)
        btnContinue.text = "Lanjutkan"
        btnContinue.setOnClickListener {
            CrashStore.clear(this)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
        root.addView(btnContinue)

        setContentView(root)
    }
}
