package com.contoh.jadwalku

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch

/** Menampilkan daftar alarm sebagai kartu dengan saklar aktif/nonaktif. */
class AlarmAdapter(
    private var items: List<AlarmItem>,
    private val onClick: (AlarmItem) -> Unit,
    private val onToggle: (AlarmItem, Boolean) -> Unit
) : RecyclerView.Adapter<AlarmAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val time: TextView = view.findViewById(R.id.tvTime)
        val label: TextView = view.findViewById(R.id.tvLabel)
        val days: TextView = view.findViewById(R.id.tvDays)
        val switch: MaterialSwitch = view.findViewById(R.id.swEnabled)
    }

    fun submit(list: List<AlarmItem>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_alarm, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val a = items[position]
        holder.time.text = a.timeText
        holder.label.text = a.label.ifBlank { "Alarm" }
        holder.days.text = daysLabel(a.days)

        // Alarm yang mati tampil lebih pudar
        holder.itemView.alpha = if (a.enabled) 1f else 0.55f

        holder.switch.setOnCheckedChangeListener(null)
        holder.switch.isChecked = a.enabled
        holder.switch.setOnCheckedChangeListener { _, checked -> onToggle(a, checked) }

        holder.itemView.setOnClickListener { onClick(a) }
    }

    override fun getItemCount() = items.size
}
