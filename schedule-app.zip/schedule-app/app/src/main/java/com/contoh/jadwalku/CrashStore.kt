package com.contoh.jadwalku

import android.content.Context
import android.os.Build
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Menyimpan laporan error di HP supaya bisa dibaca dan disalin saat aplikasi dibuka lagi. */
object CrashStore {

    private const val PREFS = "crash"
    private const val KEY = "report"

    fun save(context: Context, where: String, error: Throwable) {
        try {
            val version = try {
                context.packageManager.getPackageInfo(context.packageName, 0).versionName
            } catch (e: Exception) {
                "?"
            }
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val report = "Lokasi: $where\n" +
                "Waktu: $time\n" +
                "Versi: $version\n" +
                "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
                "Perangkat: ${Build.MANUFACTURER} ${Build.MODEL}\n\n" +
                Log.getStackTraceString(error).take(6000)

            // commit() (bukan apply) supaya benar-benar tertulis sebelum aplikasi mati
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, report).commit()
        } catch (e: Throwable) {
            // Jangan sampai pencatat error ikut membuat error
        }
    }

    fun has(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(KEY)

    fun get(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).commit()
    }
}
