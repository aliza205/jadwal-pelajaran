package com.contoh.jadwalku

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Menyimpan daftar tugas / PR. */
class HomeworkStore(context: Context) {

    private val prefs = context.getSharedPreferences("tugas", Context.MODE_PRIVATE)

    fun load(): MutableList<Homework> {
        val text = prefs.getString("items", null) ?: return mutableListOf()
        val array = JSONArray(text)
        val list = mutableListOf<Homework>()
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            list.add(
                Homework(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    subject = o.getString("subject"),
                    due = o.getString("due"),
                    done = o.getBoolean("done")
                )
            )
        }
        return list
    }

    fun save(list: List<Homework>) {
        val array = JSONArray()
        for (h in list) {
            array.put(
                JSONObject()
                    .put("id", h.id)
                    .put("title", h.title)
                    .put("subject", h.subject)
                    .put("due", h.due)
                    .put("done", h.done)
            )
        }
        prefs.edit().putString("items", array.toString()).apply()
    }
}
