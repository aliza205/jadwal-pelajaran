package com.contoh.jadwalku

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Membunyikan alarm: suara, getar, dan notifikasi layar penuh. */
class AlarmService : Service() {

    companion object {
        const val ACTION_STOP = "com.contoh.jadwalku.ALARM_STOP"
        const val ACTION_SNOOZE = "com.contoh.jadwalku.ALARM_SNOOZE"
        const val ACTION_STOPPED = "com.contoh.jadwalku.ALARM_STOPPED"
        const val EXTRA_LABEL = "label"
        const val EXTRA_TIME = "time"
        const val SNOOZE_MINUTES = 5
        private const val CHANNEL_ID = "alarm_bangun"
        private const val NOTIFICATION_ID = 42
        private const val AUTO_STOP_MS = 2 * 60 * 1000L
    }

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var currentId = -1L
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAlarm()
                return START_NOT_STICKY
            }
            ACTION_SNOOZE -> {
                snooze()
                return START_NOT_STICKY
            }
        }

        currentId = intent?.getLongExtra(AlarmScheduler.EXTRA_ID, -1L) ?: -1L
        val item = AlarmStore(this).load().firstOrNull { it.id == currentId }
        val label = item?.label?.takeIf { it.isNotBlank() } ?: "Waktunya bangun!"
        val time = item?.timeText ?: ""

        startAsForeground(label, time)
        startSound()
        startVibration()

        // Berhenti sendiri setelah 2 menit kalau tidak dimatikan
        handler.postDelayed({ stopAlarm() }, AUTO_STOP_MS)
        return START_NOT_STICKY
    }

    private fun startAsForeground(label: String, time: String) {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CHANNEL_ID, "Alarm bangun pagi", NotificationManager.IMPORTANCE_HIGH)
        channel.setSound(null, null) // suara diputar sendiri oleh layanan ini
        channel.enableVibration(false)
        channel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(channel)

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

        val ringIntent = Intent(this, RingActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(EXTRA_LABEL, label)
            .putExtra(EXTRA_TIME, time)
        val ringPi = PendingIntent.getActivity(this, 0, ringIntent, flags)

        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, AlarmService::class.java).setAction(ACTION_STOP), flags
        )
        val snoozePi = PendingIntent.getService(
            this, 2, Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE), flags
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_nav_alarm)
            .setContentTitle(label)
            .setContentText("Alarm $time")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setContentIntent(ringPi)
            .setFullScreenIntent(ringPi, true)
            .addAction(0, "Tunda $SNOOZE_MINUTES menit", snoozePi)
            .addAction(0, "Matikan", stopPi)
            .build()

        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )
    }

    private fun startSound() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            // Kalau suara gagal diputar, getar dan notifikasi tetap berjalan
        }
    }

    @Suppress("DEPRECATION")
    private fun startVibration() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 700), 0))
        vibrator = v
    }

    private fun snooze() {
        val item = AlarmStore(this).load().firstOrNull { it.id == currentId }
        if (item != null) AlarmScheduler.snooze(this, item, SNOOZE_MINUTES)
        stopAlarm()
    }

    private fun stopAlarm() {
        handler.removeCallbacksAndMessages(null)
        player?.let {
            try {
                it.stop()
            } catch (e: Exception) {
            }
            it.release()
        }
        player = null
        vibrator?.cancel()
        vibrator = null

        // Beri tahu layar alarm supaya menutup diri
        sendBroadcast(Intent(ACTION_STOPPED).setPackage(packageName))

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        vibrator?.cancel()
        super.onDestroy()
    }
}
