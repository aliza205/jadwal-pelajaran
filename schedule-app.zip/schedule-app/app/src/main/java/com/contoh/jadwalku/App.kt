package com.contoh.jadwalku

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

/** Dijalankan sekali saat aplikasi dibuka: terapkan tema dan pasang pencatat error. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(ThemePrefs.get(this))

        // Kalau aplikasi error, simpan laporannya lalu biarkan sistem menutup aplikasi seperti biasa
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            CrashStore.save(this, "thread ${thread.name}", error)
            previous?.uncaughtException(thread, error)
        }
    }
}
