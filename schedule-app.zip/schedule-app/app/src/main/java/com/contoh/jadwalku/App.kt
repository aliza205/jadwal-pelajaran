package com.contoh.jadwalku

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

/** Dijalankan sekali saat aplikasi dibuka: terapkan tema yang tersimpan. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(ThemePrefs.get(this))
    }
}
