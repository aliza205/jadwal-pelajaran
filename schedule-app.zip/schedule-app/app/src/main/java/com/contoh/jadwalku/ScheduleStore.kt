package com.contoh.jadwalku

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Menyimpan dan membaca jadwal dari penyimpanan HP (SharedPreferences). */
class ScheduleStore(context: Context) {

    private val prefs = context.getSharedPreferences("jadwal", Context.MODE_PRIVATE)

    fun load(): MutableList<Lesson> {
        val text = prefs.getString("lessons", null)
        if (text == null) {
            // Pertama kali dibuka: isi contoh supaya tampilan tidak kosong
            val sample = sampleData()
            save(sample)
            return sample
        }
        val array = JSONArray(text)
        val list = mutableListOf<Lesson>()
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            list.add(
                Lesson(
                    id = o.getLong("id"),
                    name = o.getString("name"),
                    teacher = o.getString("teacher"),
                    room = o.getString("room"),
                    day = o.getInt("day"),
                    start = o.getString("start"),
                    end = o.getString("end"),
                    color = o.getInt("color")
                )
            )
        }
        return list
    }

    fun save(list: List<Lesson>) {
        val array = JSONArray()
        for (l in list) {
            array.put(
                JSONObject()
                    .put("id", l.id)
                    .put("name", l.name)
                    .put("teacher", l.teacher)
                    .put("room", l.room)
                    .put("day", l.day)
                    .put("start", l.start)
                    .put("end", l.end)
                    .put("color", l.color)
            )
        }
        prefs.edit().putString("lessons", array.toString()).apply()
    }

    private fun sampleData(): MutableList<Lesson> {
        val c = Palette.colors
        return mutableListOf(
            Lesson(1, "Matematika", "Bu Sari", "Ruang 101", 0, "07:00", "08:30", c[0]),
            Lesson(2, "Bahasa Indonesia", "Pak Budi", "Ruang 102", 0, "08:30", "10:00", c[1]),
            Lesson(3, "IPA", "Bu Dewi", "Lab IPA", 0, "10:15", "11:45", c[2]),
            Lesson(4, "Bahasa Inggris", "Mr. John", "Ruang 103", 1, "07:00", "08:30", c[4]),
            Lesson(5, "Olahraga", "Pak Andi", "Lapangan", 1, "08:30", "10:00", c[5]),
            Lesson(6, "Seni Budaya", "Bu Rina", "Ruang Seni", 2, "07:00", "08:30", c[3])
        )
    }
}
