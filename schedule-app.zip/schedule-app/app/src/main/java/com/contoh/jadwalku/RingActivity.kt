package com.contoh.jadwalku

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** Layar penuh yang muncul saat alarm berbunyi. */
class RingActivity : AppCompatActivity() {

    // Kalau alarm dimatikan dari notifikasi, layar ini ikut menutup
    private val stopReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            finish()
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Tampil di atas layar kunci dan nyalakan layar
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        setContentView(R.layout.activity_ring)

        findViewById<TextView>(R.id.tvRingTime).text =
            intent.getStringExtra(AlarmService.EXTRA_TIME) ?: ""
        findViewById<TextView>(R.id.tvRingLabel).text =
            intent.getStringExtra(AlarmService.EXTRA_LABEL) ?: "Waktunya bangun!"

        val btnSnooze = findViewById<Button>(R.id.btnSnooze)
        btnSnooze.text = "Tunda ${AlarmService.SNOOZE_MINUTES} menit"
        btnSnooze.setOnClickListener {
            sendToService(AlarmService.ACTION_SNOOZE)
            finish()
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            sendToService(AlarmService.ACTION_STOP)
            finish()
        }

        ContextCompat.registerReceiver(
            this, stopReceiver, IntentFilter(AlarmService.ACTION_STOPPED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    private fun sendToService(action: String) {
        startService(Intent(this, AlarmService::class.java).setAction(action))
    }

    override fun onDestroy() {
        unregisterReceiver(stopReceiver)
        super.onDestroy()
    }
}
