package com.contoh.jadwalku

import android.app.TimePickerDialog
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import com.google.android.material.textfield.TextInputEditText
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private val days = listOf("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")

    private lateinit var store: ScheduleStore
    private lateinit var lessons: MutableList<Lesson>
    private lateinit var adapter: ScheduleAdapter
    private lateinit var tabLayout: TabLayout
    private lateinit var tvSubtitle: TextView
    private lateinit var tvEmpty: TextView

    // Hari yang sedang ditampilkan (0 = Senin)
    private var day = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = ScheduleStore(this)
        lessons = store.load()

        tabLayout = findViewById(R.id.tabLayout)
        tvSubtitle = findViewById(R.id.tvSubtitle)
        tvEmpty = findViewById(R.id.tvEmpty)

        // Daftar pelajaran
        val recycler = findViewById<RecyclerView>(R.id.recyclerView)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = ScheduleAdapter(emptyList()) { lesson -> showEditor(lesson) }
        recycler.adapter = adapter

        // Tab hari
        days.forEach { tabLayout.addTab(tabLayout.newTab().setText(it)) }
        day = todayIndex()
        tabLayout.getTabAt(day)?.select()
        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                day = tab.position
                refresh()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        // Tombol tambah
        findViewById<FloatingActionButton>(R.id.fabAdd).setOnClickListener { showEditor(null) }

        refresh()
    }

    /** Hari ini dalam urutan Senin = 0 ... Minggu = 6. */
    private fun todayIndex(): Int {
        val dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) // Minggu = 1
        return (dow + 5) % 7
    }

    /** Tampilkan ulang daftar untuk hari yang dipilih. */
    private fun refresh() {
        val list = lessons.filter { it.day == day }.sortedBy { it.start }
        adapter.submit(list)
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        tvSubtitle.text = "${days[day]}  •  ${list.size} pelajaran"
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun pickTime(current: String, onPicked: (String) -> Unit) {
        val parts = current.split(":")
        TimePickerDialog(
            this,
            { _, h, m -> onPicked(String.format("%02d:%02d", h, m)) },
            parts[0].toInt(), parts[1].toInt(), true
        ).show()
    }

    /** Dialog untuk menambah (lesson = null) atau mengedit pelajaran. */
    private fun showEditor(existing: Lesson?) {
        val view = layoutInflater.inflate(R.layout.dialog_edit, null)
        val etName = view.findViewById<TextInputEditText>(R.id.etName)
        val etTeacher = view.findViewById<TextInputEditText>(R.id.etTeacher)
        val etRoom = view.findViewById<TextInputEditText>(R.id.etRoom)
        val spDay = view.findViewById<Spinner>(R.id.spDay)
        val btnStart = view.findViewById<Button>(R.id.btnStart)
        val btnEnd = view.findViewById<Button>(R.id.btnEnd)
        val colorRow = view.findViewById<LinearLayout>(R.id.colorRow)

        // Isi form dengan data lama (kalau mengedit)
        etName.setText(existing?.name ?: "")
        etTeacher.setText(existing?.teacher ?: "")
        etRoom.setText(existing?.room ?: "")

        spDay.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, days)
        spDay.setSelection(existing?.day ?: day)

        var start = existing?.start ?: "07:00"
        var end = existing?.end ?: "08:30"
        btnStart.text = "Mulai  $start"
        btnEnd.text = "Selesai  $end"
        btnStart.setOnClickListener {
            pickTime(start) { start = it; btnStart.text = "Mulai  $it" }
        }
        btnEnd.setOnClickListener {
            pickTime(end) { end = it; btnEnd.text = "Selesai  $it" }
        }

        // Deretan bulatan warna; yang dipilih diberi garis tepi
        var selectedColor = existing?.color ?: Palette.colors[0]
        fun drawColorDots() {
            colorRow.removeAllViews()
            for (c in Palette.colors) {
                val dot = View(this)
                val shape = GradientDrawable()
                shape.shape = GradientDrawable.OVAL
                shape.setColor(c)
                if (c == selectedColor) shape.setStroke(dp(3), Color.parseColor("#2D3436"))
                dot.background = shape
                val lp = LinearLayout.LayoutParams(dp(38), dp(38))
                lp.marginEnd = dp(10)
                dot.setOnClickListener {
                    selectedColor = c
                    drawColorDots()
                }
                colorRow.addView(dot, lp)
            }
        }
        drawColorDots()

        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) "Tambah pelajaran" else "Edit pelajaran")
            .setView(view)
            .setPositiveButton("Simpan", null) // diatur ulang di bawah supaya bisa validasi
            .setNegativeButton("Batal", null)

        if (existing != null) {
            builder.setNeutralButton("Hapus") { _, _ ->
                lessons.removeAll { it.id == existing.id }
                store.save(lessons)
                refresh()
            }
        }

        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val name = etName.text.toString().trim()
                if (name.isEmpty()) {
                    etName.error = "Nama pelajaran wajib diisi"
                    return@setOnClickListener
                }
                if (end <= start) {
                    Toast.makeText(this, "Jam selesai harus setelah jam mulai", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val lesson = Lesson(
                    id = existing?.id ?: System.currentTimeMillis(),
                    name = name,
                    teacher = etTeacher.text.toString().trim(),
                    room = etRoom.text.toString().trim(),
                    day = spDay.selectedItemPosition,
                    start = start,
                    end = end,
                    color = selectedColor
                )

                if (existing == null) {
                    lessons.add(lesson)
                } else {
                    val index = lessons.indexOfFirst { it.id == existing.id }
                    if (index >= 0) lessons[index] = lesson
                }
                store.save(lessons)

                // Pindah ke tab hari pelajaran tersebut
                day = lesson.day
                tabLayout.getTabAt(day)?.select()
                refresh()
                dialog.dismiss()
            }
        }
        dialog.show()
    }
}
