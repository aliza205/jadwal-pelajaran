package com.contoh.jadwalku

import android.os.Build
import android.os.Bundle
import android.view.MenuItem
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.pm.PackageInfoCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Wadah utama. Berisi empat halaman (fragment) yang dipilih lewat menu bawah.
 * Fragment disembunyikan, bukan dihapus, supaya timer Fokus tetap jalan saat pindah menu.
 */
class MainActivity : AppCompatActivity() {

    private val tags = listOf("jadwal", "tugas", "nilai", "fokus")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Pertama kali dibuka: pasang semua halaman, hanya Jadwal yang terlihat
        if (savedInstanceState == null) {
            val tx = supportFragmentManager.beginTransaction()
            tx.add(R.id.container, ScheduleFragment(), "jadwal")
            val others = listOf(
                "tugas" to TasksFragment(),
                "nilai" to GradesFragment(),
                "fokus" to FocusFragment()
            )
            for ((tag, fragment) in others) {
                tx.add(R.id.container, fragment, tag)
                tx.hide(fragment)
            }
            tx.commit()
        }

        val nav = findViewById<BottomNavigationView>(R.id.bottomNav)
        nav.setOnItemSelectedListener { item: MenuItem ->
            val selected = when (item.itemId) {
                R.id.nav_schedule -> "jadwal"
                R.id.nav_tasks -> "tugas"
                R.id.nav_grades -> "nilai"
                else -> "fokus"
            }
            val tx = supportFragmentManager.beginTransaction()
            for (tag in tags) {
                val f = supportFragmentManager.findFragmentByTag(tag) ?: continue
                if (tag == selected) tx.show(f) else tx.hide(f)
            }
            tx.commit()
            true
        }

        findViewById<ImageButton>(R.id.btnTheme).setOnClickListener { showThemeDialog() }
        findViewById<ImageButton>(R.id.btnInfo).setOnClickListener { showAboutDialog() }
    }

    /** Dialog "Tentang": versi aplikasi dan info perangkat. */
    @Suppress("DEPRECATION")
    private fun showAboutDialog() {
        val info = packageManager.getPackageInfo(packageName, 0)
        val build = PackageInfoCompat.getLongVersionCode(info)
        val updated = SimpleDateFormat("d MMM yyyy, HH:mm", Locale("id", "ID"))
            .format(Date(info.lastUpdateTime))

        val message = "Versi: ${info.versionName}\n" +
            "Build: $build\n" +
            "Diperbarui: $updated\n\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "Perangkat: ${Build.MANUFACTURER} ${Build.MODEL}"

        MaterialAlertDialogBuilder(this)
            .setTitle("Tentang ${getString(R.string.app_name)}")
            .setMessage(message)
            .setPositiveButton("Tutup", null)
            .show()
    }

    /** Dialog pilihan tema. Pilihan disimpan dan langsung diterapkan. */
    private fun showThemeDialog() {
        val names = arrayOf("Ikuti sistem", "Terang", "Gelap")
        val modes = intArrayOf(
            AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM,
            AppCompatDelegate.MODE_NIGHT_NO,
            AppCompatDelegate.MODE_NIGHT_YES
        )
        val current = modes.indexOf(ThemePrefs.get(this)).coerceAtLeast(0)

        MaterialAlertDialogBuilder(this)
            .setTitle("Tema aplikasi")
            .setSingleChoiceItems(names, current) { dialog, which ->
                ThemePrefs.set(this, modes[which])
                dialog.dismiss()
                AppCompatDelegate.setDefaultNightMode(modes[which])
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
