package com.contoh.jadwalku

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.content.pm.PackageInfoCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.os.Build

/**
 * Wadah utama. Berisi empat halaman (fragment) yang dipilih lewat bar bawah.
 * Tombol + di tengah bar menambah item di halaman yang sedang dibuka.
 */
class MainActivity : AppCompatActivity() {

    private class Tab(val tag: String, val button: View, val icon: ImageView, val label: TextView)

    private val tabs = mutableListOf<Tab>()
    private var currentTag = "jadwal"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Kalau aplikasi sebelumnya error, tampilkan laporannya dulu
        if (CrashStore.has(this)) {
            startActivity(Intent(this, CrashActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        // Pertama kali dibuka: pasang semua halaman, hanya Jadwal yang terlihat
        if (savedInstanceState == null) {
            val tx = supportFragmentManager.beginTransaction()
            tx.add(R.id.container, ScheduleFragment(), "jadwal")
            val others = listOf(
                "tugas" to TasksFragment(),
                "nilai" to GradesFragment(),
                "alarm" to AlarmFragment()
            )
            for ((tag, fragment) in others) {
                tx.add(R.id.container, fragment, tag)
                tx.hide(fragment)
            }
            tx.commit()
        }
        currentTag = savedInstanceState?.getString("tab") ?: "jadwal"

        tabs.add(Tab("jadwal", findViewById(R.id.tabSchedule), findViewById(R.id.icSchedule), findViewById(R.id.lbSchedule)))
        tabs.add(Tab("tugas", findViewById(R.id.tabTasks), findViewById(R.id.icTasks), findViewById(R.id.lbTasks)))
        tabs.add(Tab("nilai", findViewById(R.id.tabGrades), findViewById(R.id.icGrades), findViewById(R.id.lbGrades)))
        tabs.add(Tab("alarm", findViewById(R.id.tabAlarm), findViewById(R.id.icAlarm), findViewById(R.id.lbAlarm)))
        for (tab in tabs) {
            tab.button.setOnClickListener { select(tab.tag) }
        }
        updateTabColors()

        // Tombol + di tengah: tambah item di halaman yang sedang dibuka
        findViewById<FloatingActionButton>(R.id.fabAdd).setOnClickListener {
            (supportFragmentManager.findFragmentByTag(currentTag) as? Addable)?.onAdd()
        }

        findViewById<ImageButton>(R.id.btnTheme).setOnClickListener { showThemeDialog() }
        findViewById<ImageButton>(R.id.btnInfo).setOnClickListener { showAboutDialog() }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tab", currentTag)
    }

    /** Tampilkan satu halaman, sembunyikan yang lain. */
    private fun select(tag: String) {
        val tx = supportFragmentManager.beginTransaction()
        for (t in tabs) {
            val f = supportFragmentManager.findFragmentByTag(t.tag) ?: continue
            if (t.tag == tag) tx.show(f) else tx.hide(f)
        }
        tx.commit()
        currentTag = tag
        updateTabColors()
    }

    /** Tab yang aktif berwarna aksen, yang lain abu-abu. */
    private fun updateTabColors() {
        for (t in tabs) {
            val color = ContextCompat.getColor(
                this,
                if (t.tag == currentTag) R.color.accent else R.color.text_secondary
            )
            t.icon.setColorFilter(color)
            t.label.setTextColor(color)
        }
    }

    /** Dialog pilihan tema. Pilihan disimpan dan langsung diterapkan. */
    private fun showThemeDialog() {
        val names = arrayOf("Ikuti sistem", "Terang", "Gelap")
        val modes = intArrayOf(
            AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM,
            AppCompatDelegate.MODE_NIGHT_NO,
            AppCompatDelegate.MODE_NIGHT_YES
        )
        val current = modes.indexOf(ThemePrefs.get(this)).coerceAtLeast(0)

        MaterialAlertDialogBuilder(this)
            .setTitle("Tema aplikasi")
            .setSingleChoiceItems(names, current) { dialog, which ->
                ThemePrefs.set(this, modes[which])
                dialog.dismiss()
                AppCompatDelegate.setDefaultNightMode(modes[which])
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Dialog "Tentang": versi aplikasi dan info perangkat. */
    @Suppress("DEPRECATION")
    private fun showAboutDialog() {
        val info = packageManager.getPackageInfo(packageName, 0)
        val build = PackageInfoCompat.getLongVersionCode(info)
        val updated = SimpleDateFormat("d MMM yyyy, HH:mm", Locale("id", "ID"))
            .format(Date(info.lastUpdateTime))

        val message = "Versi: ${info.versionName}\n" +
            "Build: $build\n" +
            "Diperbarui: $updated\n\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "Perangkat: ${Build.MANUFACTURER} ${Build.MODEL}"

        MaterialAlertDialogBuilder(this)
            .setTitle("Tentang ${getString(R.string.app_name)}")
            .setMessage(message)
            .setPositiveButton("Tutup", null)
            .show()
    }
}
