package com.contoh.jadwalku

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.content.pm.PackageInfoCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Wadah utama. Berisi empat halaman (fragment) yang dipilih lewat bar bawah
 * bergaya neumorphism. Tombol + di tengah bar menambah item di halaman yang sedang dibuka.
 */
class MainActivity : AppCompatActivity() {

    private class Tab(val tag: String, val button: View, val pill: View, val icon: ImageView)

    private val tabs = mutableListOf<Tab>()
    private var currentTag = "jadwal"

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Kalau aplikasi sebelumnya error, tampilkan laporannya dulu
        if (CrashStore.has(this)) {
            startActivity(Intent(this, CrashActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        // Pertama kali dibuka: pasang semua halaman, hanya Jadwal yang terlihat
        if (savedInstanceState == null) {
            val tx = supportFragmentManager.beginTransaction()
            tx.add(R.id.container, ScheduleFragment(), "jadwal")
            val others = listOf(
                "tugas" to TasksFragment(),
                "nilai" to GradesFragment(),
                "alarm" to AlarmFragment()
            )
            for ((tag, fragment) in others) {
                tx.add(R.id.container, fragment, tag)
                tx.hide(fragment)
            }
            tx.commit()
        }
        currentTag = savedInstanceState?.getString("tab") ?: "jadwal"

        tabs.add(Tab("jadwal", findViewById(R.id.tabSchedule), findViewById(R.id.pillSchedule), findViewById(R.id.icSchedule)))
        tabs.add(Tab("tugas", findViewById(R.id.tabTasks), findViewById(R.id.pillTasks), findViewById(R.id.icTasks)))
        tabs.add(Tab("nilai", findViewById(R.id.tabGrades), findViewById(R.id.pillGrades), findViewById(R.id.icGrades)))
        tabs.add(Tab("alarm", findViewById(R.id.tabAlarm), findViewById(R.id.pillAlarm), findViewById(R.id.icAlarm)))
        for (tab in tabs) {
            tab.pill.setLayerType(View.LAYER_TYPE_SOFTWARE, null) // supaya bayangan tampil
            tab.button.setOnClickListener { select(tab.tag) }
        }

        // Latar bar yang timbul
        val barBg = findViewById<View>(R.id.barBg)
        barBg.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        barBg.background = NeumorphDrawable(this, cornerDp = 30f)

        // Tombol + di tengah: bulat, timbul, berwarna aksen
        val fab = findViewById<ImageButton>(R.id.fabAdd)
        fab.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        fab.background = NeumorphDrawable(
            this,
            cornerDp = 100f,
            fillColor = ContextCompat.getColor(this, R.color.accent),
            blurDp = 8f,
            offsetDp = 4f
        )
        // Efek tertekan: mengecil sedikit saat disentuh
        fab.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
        // Tambah item di halaman yang sedang dibuka
        fab.setOnClickListener {
            (supportFragmentManager.findFragmentByTag(currentTag) as? Addable)?.onAdd()
        }

        updateTabs()

        findViewById<ImageButton>(R.id.btnTheme).setOnClickListener { showThemeDialog() }
        findViewById<ImageButton>(R.id.btnInfo).setOnClickListener { showAboutDialog() }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tab", currentTag)
    }

    /** Tampilkan satu halaman, sembunyikan yang lain. */
    private fun select(tag: String) {
        val tx = supportFragmentManager.beginTransaction()
        for (t in tabs) {
            val f = supportFragmentManager.findFragmentByTag(t.tag) ?: continue
            if (t.tag == tag) tx.show(f) else tx.hide(f)
        }
        tx.commit()
        currentTag = tag
        updateTabs()
    }

    /** Menu aktif: ikon berwarna aksen di dalam kotak cekung. Yang lain: ikon abu-abu, datar. */
    private fun updateTabs() {
        for (t in tabs) {
            val active = t.tag == currentTag
            val color = ContextCompat.getColor(this, if (active) R.color.accent else R.color.text_secondary)
            t.icon.setColorFilter(color)
            t.pill.background = if (active) {
                NeumorphDrawable(this, cornerDp = 16f, inset = true, blurDp = 6f, offsetDp = 3f)
            } else {
                null
            }
        }
    }

    /** Dialog pilihan tema. Pilihan disimpan dan langsung diterapkan. */
    private fun showThemeDialog() {
        val names = arrayOf("Ikuti sistem", "Terang", "Gelap")
        val modes = intArrayOf(
            AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM,
            AppCompatDelegate.MODE_NIGHT_NO,
            AppCompatDelegate.MODE_NIGHT_YES
        )
        val current = modes.indexOf(ThemePrefs.get(this)).coerceAtLeast(0)

        MaterialAlertDialogBuilder(this)
            .setTitle("Tema aplikasi")
            .setSingleChoiceItems(names, current) { dialog, which ->
                ThemePrefs.set(this, modes[which])
                dialog.dismiss()
                AppCompatDelegate.setDefaultNightMode(modes[which])
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Dialog "Tentang": versi aplikasi dan info perangkat. */
    @Suppress("DEPRECATION")
    private fun showAboutDialog() {
        val info = packageManager.getPackageInfo(packageName, 0)
        val build = PackageInfoCompat.getLongVersionCode(info)
        val updated = SimpleDateFormat("d MMM yyyy, HH:mm", Locale("id", "ID"))
            .format(Date(info.lastUpdateTime))

        val message = "Versi: ${info.versionName}\n" +
            "Build: $build\n" +
            "Diperbarui: $updated\n\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "Perangkat: ${Build.MANUFACTURER} ${Build.MODEL}"

        MaterialAlertDialogBuilder(this)
            .setTitle("Tentang ${getString(R.string.app_name)}")
            .setMessage(message)
            .setPositiveButton("Tutup", null)
            .show()
    }
}
