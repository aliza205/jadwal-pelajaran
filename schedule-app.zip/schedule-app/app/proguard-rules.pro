# Aturan R8 untuk JadwalKu.
# Komponen di AndroidManifest (Activity, Receiver, Service) dijaga otomatis oleh Android Gradle Plugin.
# Aplikasi ini tidak memakai refleksi atau library JSON pihak ketiga, jadi tidak perlu aturan tambahan.

# Pertahankan nomor baris supaya laporan error di layar CrashActivity tetap bisa dilacak
# (dicocokkan dengan mapping.txt dari build yang sama).
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
