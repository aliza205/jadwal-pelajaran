# JadwalKu

Aplikasi jadwal pelajaran Android (Kotlin) yang bisa diedit.

## Fitur
- Tab per hari (Senin - Minggu), otomatis membuka hari ini
- Kartu pelajaran berwarna: jam, nama, guru, ruang
- Tambah pelajaran dengan tombol **+**
- Ketuk kartu untuk **mengedit** atau **menghapus**
- Pilih hari, jam (pemilih jam), dan warna
- Data tersimpan di HP, tidak hilang saat aplikasi ditutup

## Cara menjalankan
1. Buka folder `schedule-app` di **Android Studio** (File > Open).
2. Tunggu Gradle Sync selesai.
3. Klik **Run** (segitiga hijau) dengan HP atau emulator.

## Cara membuat APK
**Build > Build Bundle(s) / APK(s) > Build APK(s)**, lalu klik *locate*.
File ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Struktur kode
| File | Fungsi |
|------|--------|
| `Lesson.kt` | Data pelajaran + pilihan warna |
| `ScheduleStore.kt` | Simpan dan baca data (juga berisi contoh jadwal awal) |
| `ScheduleAdapter.kt` | Menampilkan kartu pelajaran |
| `MainActivity.kt` | Layar utama, tab hari, dialog tambah/edit |

## Mengubah contoh jadwal awal
Edit fungsi `sampleData()` di `ScheduleStore.kt`. Contoh hanya muncul saat aplikasi
pertama kali dibuka; untuk melihat ulang, hapus data aplikasi di pengaturan HP.
