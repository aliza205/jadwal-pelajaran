# JadwalKu

Aplikasi pendamping sekolah untuk Android (Kotlin). Semua data tersimpan di HP.

## Fitur
Menu bawah punya 4 halaman:

- **Jadwal** - tab Senin sampai Minggu, kartu pelajaran berwarna, tambah/edit/hapus
- **Tugas** - daftar PR dengan tenggat. Centang kalau sudah selesai. Yang terlambat
  berwarna merah, yang belum selesai selalu di atas
- **Nilai** - catat nilai (Ulangan Harian, Tugas, UTS, UAS, Praktik). Rata-rata
  keseluruhan dan rata-rata per pelajaran dihitung otomatis. Warna lencana:
  hijau (75 ke atas), oranye (60-74), merah (di bawah 60)
- **Fokus** - timer belajar teknik Pomodoro (Fokus 25 menit, Istirahat 5 atau 15 menit),
  menghitung sesi fokus yang selesai hari ini. Timer tetap jalan saat pindah menu

Nama pelajaran di Tugas dan Nilai otomatis disarankan dari Jadwal.

## Info versi
Ketuk ikon **i** di pojok kanan atas untuk melihat versi, nomor build, tanggal
pembaruan, dan info perangkat. Untuk mengubah nomor versi, edit `versionName`
dan `versionCode` di `app/build.gradle.kts` (naikkan `versionCode` setiap rilis baru).

## Mode terang dan gelap
Ketuk ikon setengah lingkaran di pojok kanan atas untuk memilih **Ikuti sistem**,
**Terang**, atau **Gelap**. Pilihan tersimpan. Semua warna tema ada di
`res/values/colors.xml` (siang) dan `res/values-night/colors.xml` (malam), jadi
mudah diubah di satu tempat.

## Cara menjalankan
1. Buka folder `schedule-app` di **Android Studio** (File > Open).
2. Tunggu Gradle Sync selesai.
3. Klik **Run** dengan HP atau emulator.

## Cara membuat APK
**Build > Build Bundle(s) / APK(s) > Build APK(s)**, lalu klik *locate*.
File ada di `app/build/outputs/apk/debug/app-debug.apk`.
Tanpa komputer: gunakan GitHub Actions lewat file `.github/workflows/build.yml`.

## Struktur kode
| File | Fungsi |
|------|--------|
| `MainActivity.kt` | Wadah dan menu bawah |
| `ScheduleFragment.kt` | Halaman Jadwal |
| `TasksFragment.kt` | Halaman Tugas |
| `GradesFragment.kt` | Halaman Nilai |
| `FocusFragment.kt` | Halaman Fokus (timer) |
| `Lesson.kt`, `Models.kt` | Bentuk data + bantuan tanggal |
| `*Store.kt` | Simpan dan baca data |
| `*Adapter.kt` | Menampilkan daftar kartu |
