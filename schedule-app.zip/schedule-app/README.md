# JadwalKu

Aplikasi pendamping sekolah untuk Android (Kotlin). Semua data tersimpan di HP.

## Fitur
Bar bawah: **Jadwal - Tugas - [ + ] - Nilai - Alarm**

- **Jadwal** - tab Senin sampai Minggu, kartu pelajaran berwarna, tambah/edit/hapus
- **Tugas** - daftar PR dengan tenggat. Centang kalau sudah selesai. Yang terlambat
  berwarna merah, yang belum selesai selalu di atas
- **Nilai** - catat nilai (Ulangan Harian, Tugas, UTS, UAS, Praktik). Rata-rata
  keseluruhan dan per pelajaran dihitung otomatis
- **Alarm** - alarm bangun pagi: atur jam, label, dan hari berulang (Sen - Min),
  hidupkan/matikan dengan saklar. Saat berbunyi: suara alarm, getar, layar penuh
  dengan tombol **Matikan** dan **Tunda 5 menit**. Alarm tetap berbunyi walau aplikasi
  ditutup dan dipasang ulang otomatis setelah HP restart

Tombol **+** di tengah bar menambah item di halaman yang sedang dibuka
(pelajaran, tugas, nilai, atau alarm).

Nama pelajaran di Tugas dan Nilai otomatis disarankan dari Jadwal.

## Info versi
Ketuk ikon **i** di pojok kanan atas untuk melihat versi, nomor build, tanggal
pembaruan, dan info perangkat. Untuk mengubah nomor versi, edit `versionName`
dan `versionCode` di `app/build.gradle.kts` (naikkan `versionCode` setiap rilis baru).

## Mode terang dan gelap
Ketuk ikon setengah lingkaran di pojok kanan atas untuk memilih **Ikuti sistem**,
**Terang**, atau **Gelap**. Pilihan tersimpan. Semua warna tema ada di
`res/values/colors.xml` (siang) dan `res/values-night/colors.xml` (malam).

## Catatan penting untuk alarm
- Android 13 ke atas meminta izin **notifikasi** saat pertama menambah alarm. Izinkan,
  supaya layar alarm bisa muncul.
- Beberapa merek HP (Xiaomi, Oppo, Vivo, Realme, Samsung) mematikan aplikasi di latar
  untuk hemat baterai. Agar alarm andal: di pengaturan HP, set baterai aplikasi ini ke
  **Tanpa batasan** dan aktifkan **Mulai otomatis** (kalau ada).
- Uji alarm dulu: buat alarm 2 menit dari sekarang sebelum mengandalkannya besok pagi.

## Cara menjalankan
1. Buka folder `schedule-app` di **Android Studio** (File > Open).
2. Tunggu Gradle Sync selesai.
3. Klik **Run** dengan HP atau emulator.

## Cara membuat APK
**Build > Build Bundle(s) / APK(s) > Build APK(s)**, lalu klik *locate*.
File ada di `app/build/outputs/apk/debug/app-debug.apk`.
Tanpa komputer: gunakan GitHub Actions lewat file `.github/workflows/build.yml`.

## Struktur kode
| File | Fungsi |
|------|--------|
| `MainActivity.kt` | Wadah, bar bawah, tombol + di tengah |
| `ScheduleFragment.kt` | Halaman Jadwal |
| `TasksFragment.kt` | Halaman Tugas |
| `GradesFragment.kt` | Halaman Nilai |
| `AlarmFragment.kt` | Halaman Alarm (daftar + form) |
| `AlarmScheduler.kt` | Memasang/membatalkan alarm ke sistem Android |
| `AlarmReceiver.kt` | Dipanggil sistem saat waktu alarm tiba |
| `AlarmService.kt` | Membunyikan suara, getar, dan notifikasi |
| `RingActivity.kt` | Layar penuh saat alarm berbunyi |
| `BootReceiver.kt` | Memasang ulang alarm setelah HP restart |
| `Lesson.kt`, `Models.kt`, `Alarm.kt` | Bentuk data |
| `*Store.kt` | Simpan dan baca data |
| `*Adapter.kt` | Menampilkan daftar kartu |
